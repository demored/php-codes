<?php
declare(strict_types=1);

namespace Kafka\Exception;

use Kafka\Exception;

class NotSupported extends Exception
{
}
